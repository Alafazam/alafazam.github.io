GPU Test Bench — https://alafazam.com/tools/gpu-test-bench/
Story: https://alafazam.com/blog/old-nvidia-gpu-linux

Run it on your own Linux machine to get the live GPU/CPU temperature, CPU and memory graphs:

    python3 serve.py            # then open http://127.0.0.1:8767 in your browser

Needs only Python 3 (standard library). serve.py listens on localhost only and reads
/sys (hwmon temperatures) and /proc (CPU, memory); nothing is sent anywhere.

Files:
  index.html      the page (works on its own too, minus the live stats)
  serve.py        tiny local server: serves the page + /stats.json
  sample.mp4      10 s 1080p H.264 test clip
  make-sample.sh  regenerate sample.mp4 with ffmpeg
