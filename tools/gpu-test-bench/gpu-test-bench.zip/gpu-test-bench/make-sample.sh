#!/usr/bin/env bash
# Generate the 10-second 1080p H.264 test clip (sample.mp4) locally with ffmpeg — nothing is downloaded.
set -euo pipefail
cd "$(dirname "$0")"
ffmpeg -hide_banner -loglevel error -y -f lavfi -i testsrc2=size=1920x1080:rate=30 -t 10 \
  -c:v libx264 -preset veryfast -pix_fmt yuv420p -movflags +faststart sample.mp4
echo "sample.mp4: $(du -h sample.mp4 | cut -f1)"
