#!/usr/bin/env python3
"""Serve the GPU test page plus live system stats at /stats.json (localhost only, stdlib only).

    python3 tools/gpu-video-test/serve.py          # http://127.0.0.1:8767
    python3 tools/gpu-video-test/serve.py 9000     # another port

The page also works without this server (e.g. on a static blog) — it just hides the live stats.
"""
import glob
import http.server
import json
import os
import platform
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else int(os.environ.get("PORT", 8767))


def read(path, default=None):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return default


def run(*cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=10).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def hwmon_temp(name=None, device_glob=None):
    """First temp1_input (°C) of a hwmon by chip name, or under a device path."""
    paths = glob.glob(device_glob) if device_glob else glob.glob("/sys/class/hwmon/hwmon*")
    for h in paths:
        if name and read(f"{h}/name") != name:
            continue
        t = read(f"{h}/temp1_input")
        if t:
            return round(int(t) / 1000)
    return None


def static_info():
    gpu = ""
    for line in run("lspci", "-mm").splitlines():
        if re.search(r'"(VGA|3D|Display)', line):
            parts = re.findall(r'"([^"]*)"', line)
            gpu = f"{parts[1]} {parts[2]}" if len(parts) > 2 else line
            break
    driver = ""
    for card in glob.glob("/sys/class/drm/card[0-9]/device/driver"):
        driver = os.path.basename(os.path.realpath(card))
    glx = run("glxinfo", "-B")
    mesa = re.search(r"OpenGL core profile version string:.*?(Mesa [\w.\-~+]+)", glx)
    renderer = re.search(r"OpenGL renderer string: (.+)", glx)
    cpu = re.search(r"model name\s*:\s*(.+)", read("/proc/cpuinfo", ""))
    return {
        "gpu": gpu,
        "driver": driver,
        "renderer": renderer.group(1) if renderer else "",
        "mesa": mesa.group(1) if mesa else "",
        "kernel": platform.release(),
        "cpu": cpu.group(1) if cpu else "",
        "threads": os.cpu_count(),
    }


INFO = static_info()
_last_cpu = None


def cpu_percent():
    global _last_cpu
    fields = [int(x) for x in read("/proc/stat").splitlines()[0].split()[1:]]
    idle, total = fields[3] + fields[4], sum(fields)
    pct = None
    if _last_cpu:
        di, dt = idle - _last_cpu[0], total - _last_cpu[1]
        pct = round(100 * (1 - di / dt), 1) if dt else 0.0
    _last_cpu = (idle, total)
    return pct


def mem_percent():
    m = dict(re.findall(r"(\w+):\s+(\d+)", read("/proc/meminfo", "")))
    total, avail = int(m.get("MemTotal", 0)), int(m.get("MemAvailable", 0))
    return round(100 * (1 - avail / total), 1) if total else None


def stats():
    return {
        "time": time.time(),
        "gpu_temp": hwmon_temp(device_glob="/sys/class/drm/card[0-9]/device/hwmon/hwmon*"),
        "cpu_temp": hwmon_temp(name="coretemp") or hwmon_temp(name="k10temp"),
        "cpu_percent": cpu_percent(),
        "mem_percent": mem_percent(),
        "gpu_power": read(glob.glob("/sys/class/drm/card[0-9]/device/power_state")[0])
        if glob.glob("/sys/class/drm/card[0-9]/device/power_state") else None,
        "load": os.getloadavg()[0],
        "info": INFO,
    }


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=HERE, **kw)

    def do_GET(self):
        if self.path.split("?")[0] == "/stats.json":
            body = json.dumps(stats()).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            super().do_GET()

    def log_message(self, *a):  # keep the terminal quiet
        pass


if __name__ == "__main__":
    print(f"GPU test page: http://127.0.0.1:{PORT}/  (Ctrl+C to stop)")
    http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
